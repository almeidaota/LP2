﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public static SqlConnection connect;

        public Form1()
        {
            InitializeComponent();
        }

        //private void cadastroDeDespesasToolStripMenuItem_Click(object sender, EventArgs e)
        //{

        //if (Application.OpenForms.OfType<frmDespesa>().Count() > 0)
        //{
        // Application.OpenForms["frmDespesa"].BringToFront();
        //}Data Source=DESKTOP-O7LP3PQ;Initial Catalog=LP2;Integrated Security=True
        //else  
        //{
        //  frmDespesa objDesp = new frmDespesa();
        //objDesp.MdiParent = this;
        //objDesp.WindowState = FormWindowState.Maximized;
        //objDesp.Show();
        //}

        //}

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                // aqui a conexão vai depende da sua máquina da escola ou particular
                connect = new SqlConnection("Data Source=DESKTOP-O7LP3PQ;Initial Catalog=LP2;Integrated Security=True");
                connect.Open();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro de banco de dados =/" + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Outros Erros =/" + ex.Message);
            }
        }

        private void controleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmDespesa>().Count() > 0)
            {
                Application.OpenForms["frmDespesa"].BringToFront();
            }
            else
            {
                frmDespesa objDesp = new frmDespesa();
                objDesp.MdiParent = this;
                objDesp.WindowState = FormWindowState.Maximized;
                objDesp.Show();
            }
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<sobre>().Count() > 0)
            {
                Application.OpenForms["sobre"].BringToFront();
            }
            else
            {
                sobre objDesp = new sobre();
                objDesp.MdiParent = this;
                objDesp.WindowState = FormWindowState.Maximized;
                objDesp.Show();
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}