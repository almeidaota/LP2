﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATIVIDADE_3
{
    public partial class Form1 : Form
    {
        double altura, peso, resultado;

        public Form1()
        {
            InitializeComponent();
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            resultado = 0;
            peso = 0;
            altura = 0;

            txt3.Text = "";
            txtbox1.Text = "";
            txtbox2.Text = "";
        }

        private void txtbox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
        }

        private void txtbox1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtbox1.Text, out altura))
            {
                MessageBox.Show("Digite um valor válido.");
                txtbox1.Focus();
            }
        }

        private void txtbox2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtbox2.Text, out peso))
            {
                MessageBox.Show("Digite um valor válido.");
                txtbox2.Focus();
            }
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("tchauuuu");
            Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void btn1_Click(object sender, EventArgs e)
        {
           
            resultado = peso / (altura*altura);
            resultado = resultado * 100;

           if(resultado < 18.5)
            {
                txt3.Text = resultado.ToString();
                MessageBox.Show("Abaixo do peso");
            }
           else if (resultado < 24.9)
            {
                txt3.Text = resultado.ToString();
                MessageBox.Show("Peso Ideal");
            }
           else if (resultado < 29.9)
            {
                txt3.Text = resultado.ToString();
                MessageBox.Show("Acima do peso");
            }
           else if (resultado < 34.9)
            {
                txt3.Text = resultado.ToString();
                MessageBox.Show("Obesidade grau I");
            }
           else if (resultado < 39.9)
            {
                txt3.Text = resultado.ToString();
                MessageBox.Show("Obesidade Grau 2");
            }
           else if (resultado > 40)
            {
                txt3.Text = resultado.ToString();
                MessageBox.Show("Obesidade Grau 3");
            }
        }
    }
}
