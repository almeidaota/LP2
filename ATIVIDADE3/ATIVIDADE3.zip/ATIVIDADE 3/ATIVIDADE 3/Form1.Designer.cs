﻿namespace ATIVIDADE_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.txt3 = new System.Windows.Forms.TextBox();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.txtbox1 = new System.Windows.Forms.MaskedTextBox();
            this.txtbox2 = new System.Windows.Forms.MaskedTextBox();
            this.SuspendLayout();
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Location = new System.Drawing.Point(77, 62);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(34, 13);
            this.lbl1.TabIndex = 0;
            this.lbl1.Text = "Altura";
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Location = new System.Drawing.Point(76, 111);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(31, 13);
            this.lbl2.TabIndex = 1;
            this.lbl2.Text = "Peso";
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Location = new System.Drawing.Point(77, 171);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(55, 13);
            this.lbl3.TabIndex = 2;
            this.lbl3.Text = "Resultado";
            // 
            // txt3
            // 
            this.txt3.Location = new System.Drawing.Point(167, 168);
            this.txt3.Name = "txt3";
            this.txt3.Size = new System.Drawing.Size(384, 20);
            this.txt3.TabIndex = 5;
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(80, 262);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(139, 68);
            this.btn1.TabIndex = 6;
            this.btn1.Text = "calcular";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // btn2
            // 
            this.btn2.Location = new System.Drawing.Point(365, 262);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(139, 68);
            this.btn2.TabIndex = 7;
            this.btn2.Text = "limpar";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // btn3
            // 
            this.btn3.Location = new System.Drawing.Point(627, 262);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(139, 68);
            this.btn3.TabIndex = 8;
            this.btn3.Text = "sair";
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // txtbox1
            // 
            this.txtbox1.Location = new System.Drawing.Point(167, 55);
            this.txtbox1.Mask = "9,99";
            this.txtbox1.Name = "txtbox1";
            this.txtbox1.Size = new System.Drawing.Size(384, 20);
            this.txtbox1.TabIndex = 10;
            this.txtbox1.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.txtbox1_MaskInputRejected);
            this.txtbox1.Validated += new System.EventHandler(this.txtbox1_Validated);
            // 
            // txtbox2
            // 
            this.txtbox2.Location = new System.Drawing.Point(167, 108);
            this.txtbox2.Mask = "099,99";
            this.txtbox2.Name = "txtbox2";
            this.txtbox2.Size = new System.Drawing.Size(384, 20);
            this.txtbox2.TabIndex = 11;
            this.txtbox2.Validated += new System.EventHandler(this.txtbox2_Validated);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtbox2);
            this.Controls.Add(this.txtbox1);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.txt3);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.TextBox txt3;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.MaskedTextBox txtbox1;
        private System.Windows.Forms.MaskedTextBox txtbox2;
    }
}

