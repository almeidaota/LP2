﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATIVIDADE4
{
    public partial class Form1 : Form
    {
        float a, b, c;

        private void txt2_Validated(object sender, EventArgs e)
        {
            if (float.TryParse(txt2.Text, out b) && b > 0)
            {

            }
            else
            {
                MessageBox.Show("Número invalido");
                txt2.Focus();
            }
        }

        private void txt3_Validated(object sender, EventArgs e)
        {
            if (float.TryParse(txt3.Text, out c) && c > 0)
            {

            }
            else
            {
                MessageBox.Show("Número invalido");
                txt3.Focus();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if((a + b) > c && (a+c) > b && (b + c) > a){
                if (a == b && b == c) {
                    MessageBox.Show("Equilátero");
                }
                else if (a != b && a != c && b != c)
                {
                    MessageBox.Show("Escaleno");
                }
                else
                {
                    MessageBox.Show("Isósceles");
                }
            }
            else
            {
                MessageBox.Show("Inválido. Digitar novamente os valores.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            a = 0;
            b = 0;
            c = 0;
            txt1.Clear();
            txt2.Clear();
            txt3.Clear();

        }

        private void bt3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("tchauuuu");
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            if (float.TryParse(txt1.Text, out a) && a > 0)
            {

            }
            else
            {
                MessageBox.Show("Número invalido");
                txt1.Focus();
            }
        }
    }
}
