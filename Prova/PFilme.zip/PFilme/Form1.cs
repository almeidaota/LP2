﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PFilme
{
    public partial class Form1 : Form
    {
        double[,] matriz = new double[2, 2];
        string aux;
        double aux2;
        double mediaFilme1 = 0;
        double mediaFilme2 = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnExecutar(object sender, EventArgs e)
        {
            for (var j = 0; j < 2; j++)
            {
                for (var i = 0; i < 2; i++)
                {
                    aux = Interaction.InputBox($"Pessoa {j + 1}, por favor, digite a nota do filme {i + 1}", "Entrada das notas");
                    if (double.TryParse(aux, out aux2))
                    {
                        if(aux2 <= 10 && aux2 >= 0)
                        {
                            matriz[j, i] = aux2;
                        }
                        else
                        {
                            MessageBox.Show("Digite uma nota entre 0 e 10");
                            i--;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Digite um numero valido");
                        i--;
                    }
                }
            }
            //calculando media do filme 1
            for(var i = 0; i < 2; i++)
            {
                mediaFilme1 = mediaFilme1 + matriz[i, 0];
            }
                mediaFilme1 = mediaFilme1 / 2;

            //calculando media do filme 2
            for (var i = 0; i < 2; i++)
            {
                mediaFilme2 += matriz[i, 1];
            }
            mediaFilme2 = mediaFilme2 / 2;


            listBoxNotaFilme.Items.Add($"Pessoa 1: Nota Filme 1: {matriz[0, 0].ToString("F")} | Nota Filme 2: {matriz[0, 1].ToString("F")}");
            listBoxNotaFilme.Items.Add($"Pessoa 2: Nota Filme 1: {matriz[1, 0].ToString("F")} | Nota Filme 2: {matriz[1, 1].ToString("F")}");

            listBoxNotaFilme.Items.Add($"-----------------------------");
            listBoxNotaFilme.Items.Add($"Media filme 1: {mediaFilme1.ToString("F")}");
            listBoxNotaFilme.Items.Add($"Media filme 2: {mediaFilme2.ToString("F")}");

            mediaFilme1 = 0;
            mediaFilme2 = 0;
        }



    }
}
