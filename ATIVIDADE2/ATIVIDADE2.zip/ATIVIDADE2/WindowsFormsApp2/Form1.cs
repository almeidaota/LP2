﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        double resultado, numero1, numero2;

        private void txt1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txt1.Text, out numero1))
            {
                MessageBox.Show("numero 1 invalido!");
                txt1.Focus();
            }
        }

        private void txt2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txt2.Text, out numero2))
            {
                MessageBox.Show("numero 2 invalido!");
                txt1.Focus();
            }

        }

        private void btn1_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txt3.Text = resultado.ToString();
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txt3.Text = resultado.ToString();

        }

        private void btn3_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txt3.Text = resultado.ToString();

        }

        private void btn4_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("Não existe divisão por zero, cabaço.", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt2.Focus();
            }
            else
            {
                resultado = numero1 / numero2;
                txt3.Text = resultado.ToString();
            }
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Você deseja sair mesmo?", "saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            txt1.Text = "";
            txt2.Text = "";
            txt3.Text = "";
            txt1.Focus();

            resultado = 0;
            numero1 = 0;
            numero2 = 0;
        }
    }
}
